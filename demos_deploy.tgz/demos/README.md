# Nexus Shield Demo Recordings

Automated Trust Hub screen recordings using Playwright (Chromium).

## Setup

```bash
cd demos
npm install
npm run install:browsers
```

## Environment

| Variable | Default | Description |
|----------|---------|-------------|
| `TRUST_HUB_URL` | `http://127.0.0.1:3000/dashboard/trust-hub` | Dashboard Trust Hub page |
| `API_BASE_URL` | `https://api.nexusshield.ai` | Fast API for agent actions / benchmark |
| `DEMO_LOGIN_EMAIL` | — | Required when Supabase auth is enabled |
| `DEMO_LOGIN_PASSWORD` | — | Required when Supabase auth is enabled |
| `NEXUS_DEMO_BYPASS_AUTH` | — | Set `1` on dashboard server for local recording without login |
| `DEMO_HEADLESS` | — | Set `1` to run headless (videos still recorded) |

## Run

From repo root:

```bash
bash scripts/run_demos.sh
```

Or individually:

```bash
cd demos
npm run demo1   # → videos/demo1_performance.webm
npm run demo2   # → videos/demo2_evidence_hitl.webm
```

## Prerequisites

1. Fast API running (`8080`) with governance routes enabled.
2. Dashboard running (`3000`) or Vercel URL in `TRUST_HUB_URL`.
3. For Demo 2, `/v1/agent/action` must return `PENDING_APPROVAL` with an `approval_id`.
