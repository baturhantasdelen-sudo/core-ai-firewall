#!/usr/bin/env bash
# Run Nexus Shield Trust Hub demo recordings (Playwright / Chromium).
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "${ROOT}/demos"

export TRUST_HUB_URL="${TRUST_HUB_URL:-http://127.0.0.1:3000/dashboard/trust-hub}"
export API_BASE_URL="${API_BASE_URL:-http://127.0.0.1:8080}"

if [[ ! -d node_modules ]]; then
  npm install
fi

npm run install:browsers
npm run demos

echo "Videos saved under ${ROOT}/demos/videos/"
